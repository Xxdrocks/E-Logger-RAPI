import React from 'react'
import LogPage from './features/logs/LogPage'

function App() {
  return (
    <div>
      <LogPage />
    </div>
  )
}

export default App
