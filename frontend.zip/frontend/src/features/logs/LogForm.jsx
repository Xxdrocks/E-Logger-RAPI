import React, { useState } from 'react';
import axios from 'axios';

function LogForm({ refresh }) {
    const [form, setForm] = useState({
        frequency: "",
        ncs_1028: "",
        waktu: "",
        zzd: "",
        nama: "",
        keterangan: "",
    });

    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await axios.post("http://127.0.0.1:8000/api/logs", form);
            setForm({ frequency: "", ncs_1028: "", waktu: "", zzd: "", nama: "", keterangan: "" });
            setSuccess(true);
            setTimeout(() => setSuccess(false), 2500);
            refresh();
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const fields = [
        { name: "frequency", placeholder: "Frequency", icon: "📡" },
        { name: "ncs_1028", placeholder: "10/28", icon: "🔢" },
        { name: "waktu", placeholder: "Waktu", icon: "🕐" },
        { name: "zzd", placeholder: "ZZD", icon: "📻" },
        { name: "nama", placeholder: "Nama", icon: "👤" },
        { name: "keterangan", placeholder: "Keterangan", icon: "📝" },
    ];

    return (
        <form onSubmit={handleSubmit} className="relative">
            {success && (
                <div className="absolute -top-14 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-emerald-500 text-white text-sm font-semibold px-5 py-2.5 rounded-full shadow-lg animate-bounce">
                    <span>✓</span> Data berhasil disimpan!
                </div>
            )}

            <div className="bg-white/70 backdrop-blur-md border border-slate-200/80 rounded-2xl shadow-xl shadow-slate-200/60 p-7">
                <div className="flex items-center gap-3 mb-6 pb-5 border-b border-slate-100">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center shadow-md shadow-indigo-200">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2.2" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                        </svg>
                    </div>
                    <div>
                        <h2 className="text-base font-bold text-slate-800 leading-tight">Input Log Baru</h2>
                        <p className="text-xs text-slate-400 mt-0.5">Isi semua field dengan benar</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                    {fields.map((field) => (
                        <div key={field.name}>
                            <label className="block text-xs font-semibold text-slate-500 mb-1.5 tracking-wide uppercase">
                                {field.icon} {field.placeholder}
                            </label>
                            <input
                                name={field.name}
                                placeholder={`Masukkan ${field.placeholder}`}
                                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/80 text-slate-800 text-sm placeholder:text-slate-300 outline-none transition-all duration-200 focus:border-indigo-400 focus:bg-white focus:ring-3 focus:ring-indigo-100 hover:border-slate-300"
                                onChange={handleChange}
                                value={form[field.name]}
                            />
                        </div>
                    ))}
                </div>

                <div className="flex justify-end">
                    <button
                        type="submit"
                        disabled={loading}
                        className="flex items-center gap-2.5 px-7 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-sm font-semibold shadow-md shadow-indigo-200 hover:shadow-lg hover:shadow-indigo-300 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:translate-y-0"
                    >
                        {loading ? (
                            <>
                                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                                </svg>
                                Menyimpan...
                            </>
                        ) : (
                            <>
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.2" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                                Simpan Log
                            </>
                        )}
                    </button>
                </div>
            </div>
        </form>
    );
}

export default LogForm;